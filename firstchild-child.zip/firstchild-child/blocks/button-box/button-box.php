<?php

/**

 * Button box Block template.

 *

 * @param array $block The block settings and attributes.

 */



// Load values and assign defaults.

$titolo = get_field( 'titolo' );

$testo = get_field( 'testo' );

$bottone = get_field( 'bottone' );

$colore_bordo = get_field( 'colore_bordo' );






// Support custom "anchor" values.

$anchor = '';

if ( ! empty( $block['anchor'] ) ) {

    $anchor = 'id="' . esc_attr( $block['anchor'] ) . '" ';

}

?>



<div <?php echo esc_attr( $anchor ); ?>class="border-solid border-4 border-[<?php echo esc_attr( $colore_bordo); ?>] py-8 px-4 rounded-xl relative hover:shadow-2xl transition duration-300">

    <div>

        <h3 class="text-center">

            <?php echo esc_html( $titolo ); ?>

        </h3>

        <p class="py-5 text-center">

            <?php echo esc_html( $testo ); ?>

        </p>

        <?php

        if( $bottone ): 

            $bottone_url = $bottone['url'];

            $bottone_title = $bottone['title'];

            $bottone_target = $bottone['target'] ? $bottone['target'] : '_self';

        ?>

        <a class="btn btn-outline absolute top-[86%] left-[10em]" href="<?php echo esc_url( $bottone_url ); ?>" target="<?php echo esc_attr( $bottone_target ); ?>"><?php echo esc_html( $bottone_title ); ?></a>

        <?php endif; ?>

    </div>

</div>

