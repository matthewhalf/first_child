<?php

/**

 * Text image bg Block template.

 *

 * @param array $block The block settings and attributes.

 */



// Load values and assign defaults.

$immagine = get_field( 'immagine' );

$titolo = get_field( 'titolo' );

$testo = get_field( 'testo' );



// Support custom "anchor" values.

$anchor = '';

if ( ! empty( $block['anchor'] ) ) {

    $anchor = 'id="' . esc_attr( $block['anchor'] ) . '" ';

}

?>

<div  <?php echo esc_attr( $anchor );?> class="mx-auto md:w-[90%] px-4 py-16 sm:px-6 lg:px-8">
    <div class="grid grid-cols-1 lg:h-screen lg:grid-cols-2">
      <div class="relative z-10 lg:py-16">
        <div class="relative h-64 sm:h-80 lg:h-full">
          <img
            alt=""
            src="<?php echo esc_url( $immagine ); ?>"
            class="absolute inset-0 h-full w-full object-cover"
          />
        </div>
      </div>

      <div class="relative flex items-center bg-[#F1F7FE]">
        <span
          class="hidden lg:absolute lg:inset-y-0 lg:-start-16 lg:block lg:w-16 lg:bg-[#F1F7FE]"
        ></span>

        <div class="p-8 sm:p-16 lg:p-24">
          <h2>
          <?php echo esc_html( $titolo ); ?>
          </h2>

          <p class="mt-4">
          <?php echo wp_kses_post( $testo ); ?>
          </p>
        </div>
      </div>
    </div>
  </div>
</section>

