<?php

/**

 * Over lap media text template.

 *

 * @param array $block The block settings and attributes.

 */



// Load values and assign defaults.

$titolo_h2 = get_field( 'titolo_h2' );

$titolo_h3 = get_field( 'titolo_h3' );

$testo = get_field( 'testo' );

$immagine_1 = get_field( 'immagine_1' );

$immagine_2 = get_field( 'immagine_2' );

$vantaggio_1 = get_field( 'vantaggio_1' );

$vantaggio_2 = get_field( 'vantaggio_2' );

$vantaggio_3 = get_field( 'vantaggio_3' );

$vantaggio_4 = get_field( 'vantaggio_4' );


// Support custom "anchor" values.

$anchor = '';

if ( ! empty( $block['anchor'] ) ) {

    $anchor = 'id="' . esc_attr( $block['anchor'] ) . '" ';

}

?>

<div <?php echo esc_attr( $anchor );?> class="relative md:w-[90%] m-auto flex flex-col justify-between overflow-hidden my-[80px]">
  <div class="w-full items-center mx-auto">
    <div class="group grid w-full md:grid-cols-2 gap-6">
      <div class="relative flex before:block before:absolute before:h-1/6 before:w-2 before:bg-stone-200 before:top-0 before:right-0 before:rounded-lg  before:transition-all group-hover:before:bg-[#09213B] overflow-hidden">
        <div class="absolute bottom-0 right-0 w-4/6 overflow-hidden flex flex-col justify-center rounded shadow-xl">
          <img src="<?php echo esc_url( $immagine_1 ); ?>" alt="">
        </div>
        
        <div class="h-2/3 rounded overflow-hidden">
          <img src="<?php echo esc_url( $immagine_2 ); ?>" class="h-full" alt="">
        </div>
    
      </div>
      <div>
        <div class="">
          <h2 class="text-5xl font-medium p-8" data-aos="fade-up" data-aos-anchor-placement="top-bottom" data-aos-duration="1000"><?php echo esc_html( $titolo_h2 ); ?></h2>
          <h3 class="text-2xl font-medium px-8" data-aos="fade-up" data-aos-anchor-placement="top-bottom" data-aos-duration="1000"><?php echo esc_html( $titolo_h3 ); ?></h3>
          <p class="p-8"><?php echo esc_html($testo); ?>
          </p>
          <div class="grid grid-cols-2 gap-6 justify-between p-8">
            <p href="" class="flex items-center gap-3 hover:text-blue-300">
              <span class="h-10 w-10 rounded-full bg-blue-300 flex items-center justify-center text-white shadow-lg shadow-blue-400/30">
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-6 h-6">
                  <path stroke-linecap="round" stroke-linejoin="round" d="m4.5 12.75 6 6 9-13.5" />
                </svg>
              </span>
              <span class="font-semibold"><?php echo esc_html( $vantaggio_1 ); ?></span>
            </p>
            <p class="flex items-center gap-3 hover:text-blue-300">
              <span class="h-10 w-10 rounded-full bg-blue-300 flex items-center justify-center text-white shadow-lg shadow-blue-400/30">
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-6 h-6">
                  <path stroke-linecap="round" stroke-linejoin="round" d="m4.5 12.75 6 6 9-13.5" />
                </svg>
              </span>
              <span class="font-semibold"><?php echo esc_html( $vantaggio_2 ); ?></span>
            </p>
          </div>
          <div class="grid grid-cols-2 gap-6 justify-between px-8 pb-3">
            <p href="" class="flex items-center gap-3 hover:text-blue-300">
              <span class="h-10 w-10 rounded-full bg-blue-300 flex items-center justify-center text-white shadow-lg shadow-blue-400/30">
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-6 h-6">
                  <path stroke-linecap="round" stroke-linejoin="round" d="m4.5 12.75 6 6 9-13.5" />
                </svg>
              </span>
              <span class="font-semibold"><?php echo esc_html( $vantaggio_3 ); ?></span>
            </p>
            <p href="" class="flex items-center gap-3 hover:text-blue-300">
              <span class="h-10 w-10 rounded-full bg-blue-300 flex items-center justify-center text-white shadow-lg shadow-blue-400/30">
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-6 h-6">
                  <path stroke-linecap="round" stroke-linejoin="round" d="m4.5 12.75 6 6 9-13.5" />
                </svg>
              </span>
              <span class="font-semibold"><?php echo esc_html( $vantaggio_4 ); ?></span>
            </p>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

