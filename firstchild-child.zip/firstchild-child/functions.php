<?php

// SECTION INCLUDO PARENT STYLES AND SCRIPT


function childtheme_parent_styles() {

 

    // enqueue parent style

    wp_enqueue_style( 'parent', get_template_directory_uri().'/style.css' );



    wp_enqueue_script( 'parent', get_template_directory_uri() . '/js/script.js', array(), false, true );

    

    // enqueue child style

    wp_enqueue_style( 'child', get_stylesheet_directory_uri().'/style.css', array('parent'), wp_get_theme()->get('Version') );

}

add_action( 'wp_enqueue_scripts', 'childtheme_parent_styles');



    /* SECTION REGISTRO CUSTOM BLOCKS

    /* ------------------------------------ */

    function firstchild_register_acf_blocks() {

        /**

         * We register our block's with WordPress's handy

         * register_block_type();

         *

         * @link https://developer.wordpress.org/reference/functions/register_block_type/

         */

        register_block_type( __DIR__ . '/blocks/button-box' );

    }

    // Here we call our tt3child_register_acf_block() function on init.

    add_action( 'init', 'firstchild_register_acf_blocks' );
