<?php
/**
 * Template Name: Page with Title
 */
?>

<?php get_header(); ?>

<div class="bg-[#f5f5f5] py-6">
    <div class="md:w-[1300px] m-auto text-center md:text-left">
         <h1 class="text-transparent bg-clip-text bg-gradient-to-r from-scooter-primary to-scooter-950"><?php the_title(); ?></h1>
    </div>
</div>

<div class="md:w-[1300px] m-auto">

  <?php if (have_posts()) :?><?php while(have_posts()) : the_post(); ?>

    <?php the_content(esc_html__('Read More...', 'slug-theme'));?>

  <?php endwhile; ?>
    <p><?php previous_posts_link( 'Older posts' ); ?> <?php next_posts_link( 'Newer posts' ); ?></p>
  <?php else : ?>
    <p><?php esc_html_e('Sorry, no posts matched your criteria.', 'slug-theme'); ?></p>
  <?php endif; ?>


</div>


<?php get_footer(); ?>