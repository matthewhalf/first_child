<?php
/**
 * Template Name: Page with Title center
 */
?>

<?php get_header(); ?>


<div class="bg-[#F1F7FE] py-6">
    <div class="md:w-[90%] m-auto text-center mt-16 px-4">
         <h1><?php the_title(); ?></h1>
    </div>
</div>

<?php if (have_posts()) :?><?php while(have_posts()) : the_post(); ?>

  <?php the_content(esc_html__('Read More...', 'slug-theme'));?>

<?php endwhile; ?>
 
<?php endif; ?>


<?php get_footer(); ?>