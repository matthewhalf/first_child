        <?php
            $copyright_text = get_field('copyright', 'option');
        ?>
        
        </div> 



            <footer class=" p-10 bg-scooter-950 ">

                <div class="footer md:w-[1300px] text-base-content m-auto">

                    <div>

                        <p>Lorem ipsum dolor<br>

                        <a href="#" target="_blank">Lorem ipsum dolor</a> <br>

                        <a href="#" target="_blank">Lorem ipsum dolor</a>

                        <br> Lorem ipsum dolor</p>

                    </div> 

                    <div>

                        <span class="footer-title">Lorem ipsum</span> 

                        <a class="link link-hover" href="#">Lorem ipsum dolor</a> 

                        <a class="link link-hover" href="#">Lorem ipsum dolor</a> 

                        <a class="link link-hover" href="#">Lorem ipsum dolor</a> 

                        <a class="link link-hover" href="#">Lorem ipsum dolor</a>

                    </div> 

                    <div>

                        <span class="footer-title">Lorem ipsum dolor</span> 

                        <a class="link link-hover" href="#">Lorem ipsum dolor</a> 

                        <a class="link link-hover" href="#">Lorem ipsum dolor</a> 

                        <a class="link link-hover" href="#" target="_blank">Lorem ipsum dolor</a> 

                    </div> 

                    <div>

                        <span class="footer-title">Lorem ipsum dolor</span> 

                        <a class="link link-hover" href="#" target="_blank">Lorem ipsum dolor</a> 

                        <a class="link link-hover" href="#" target="_blank">Lorem ipsum dolor</a>

                    </div>

                </div>

                

            </footer>

            <div class="footer-center p-4 bg-scooter-950 text-[14px] text-[#A0A8B6]">

                  <p>  <?php echo ( $copyright_text ) ?>  </p> 

            </div>



            <?php wp_footer(); ?>

        





    </body>



</html>