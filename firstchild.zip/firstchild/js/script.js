AOS.init();

function isMobile(){


  return window.innerWidth <= 768;


}





if(isMobile()) {


  // Apri il dropdown quando clicchi sul link


  document.querySelectorAll('.menu-item-has-children > a').forEach(item => {


    item.addEventListener('click', event => {


      event.preventDefault();


      let dropdownContent = event.target.nextElementSibling;


      dropdownContent.style.display = dropdownContent.style.display === 'none' ? 'block' : 'none';


    });


  });


  


  // Chiudi il dropdown quando clicchi altrove nella pagina


  window.addEventListener('click', event => {


    if (!event.target.closest('.menu-item-has-children')) {


      document.querySelectorAll('.menu-item-has-children > ul').forEach(dropdown => {


        dropdown.style.display = 'none';


      });


    }


  });


}








  