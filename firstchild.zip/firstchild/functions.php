<?php

    // SECTION THEME SETUP

    if ( ! function_exists( 'firstchild_setup' ) ) :

        

        function firstchild_setup() {

            /**

             * Add default posts and comments RSS feed links to <head>.

             */

            add_theme_support( 'title-tag' );

            /**

             * Enable support for post thumbnails and featured images.

             */

            add_theme_support( 'post-thumbnails' );

            /**

             * Enable custom logo

             */

            add_theme_support( 'custom-logo');

            /**

             * Add support for two custom navigation menus.

             */

            register_nav_menus(array(

                register_nav_menu('primary', __('Primary Menu', 'first_child')),

                register_nav_menu('footer', __('Footer Menu', 'first_child')),

            ));

                

            /**

             * Enable support for the following post formats:

             * aside, gallery, quote, image, and video

             */

            add_theme_support( 'post-formats', array( 'aside', 'gallery', 'quote', 'image', 'video' ) );

        }

    endif; // myfirsttheme_setup

    add_action( 'after_setup_theme', 'firstchild_setup' );

    

    /* ANCHOR  Includo css

    /* ------------------------------------ */ 

      function firstchild_styles() {

    

        wp_enqueue_style( 'slug-theme-style', get_template_directory_uri().'/style.css');

    

       }

    add_action( 'wp_enqueue_scripts', 'firstchild_styles' );



    // ANCHOR Includo js

    function firstchild_script() {

        wp_enqueue_script( 'slug-theme-scripts', get_stylesheet_directory_uri() . '/js/script.js', array(), false, true );

    }

    add_action( 'wp_enqueue_scripts', 'firstchild_script' );

    // ANCHOR Includo tailwind css, daisy UI e jquery

        // Funzione per caricare gli stili e gli script necessari nel tema
    function first_child_enqueue_tdj() {
        // Aggiungi jQuery nel footer
        wp_enqueue_script('jquery', 'https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js', array(), null, true);

        // Aggiungi il foglio di stile CSS
        wp_enqueue_style('daisyui-css', 'https://cdn.jsdelivr.net/npm/daisyui@3.2.1/dist/full.css');

        // Aggiungi lo script JavaScript di Tailwind CSS
        wp_enqueue_script('tailwind-js', 'https://cdn.tailwindcss.com', array(), null, true);
    }

    // Aggiungi l'hook per eseguire la funzione sopra nella coda di Wordpress
    add_action('wp_enqueue_scripts', 'first_child_enqueue_tdj');




    ///SECTION  OPZIONI TEMA
    if( function_exists('acf_add_options_page') ) {

        acf_add_options_page(array(
            'page_title'    => 'Opzioni tema',
            'menu_title'    => 'Opzioni tema',
            'menu_slug'     => 'theme-general-settings',
            'capability'    => 'edit_posts',
            'redirect'      => false
        ));
    
    }


    add_action( 'acf/include_fields', function() {
        if ( ! function_exists( 'acf_add_local_field_group' ) ) {
            return;
        }
    
        acf_add_local_field_group( array(
        'key' => 'group_65d370f992615',
        'title' => 'Stile globale bottoni',
        'fields' => array(
            array(
                'key' => 'field_65d37100bd6d4',
                'label' => 'Colore di sfondo',
                'name' => 'colore_di_sfondo',
                'aria-label' => '',
                'type' => 'color_picker',
                'instructions' => '',
                'required' => 0,
                'conditional_logic' => 0,
                'wrapper' => array(
                    'width' => '50',
                    'class' => '',
                    'id' => '',
                ),
                'default_value' => '',
                'enable_opacity' => 0,
                'return_format' => 'string',
            ),
            array(
                'key' => 'field_65d380e8795e5',
                'label' => 'Colore di sfondo:hover',
                'name' => 'colore_di_sfondo_hover',
                'aria-label' => '',
                'type' => 'color_picker',
                'instructions' => '',
                'required' => 0,
                'conditional_logic' => 0,
                'wrapper' => array(
                    'width' => '50',
                    'class' => '',
                    'id' => '',
                ),
                'default_value' => '',
                'enable_opacity' => 0,
                'return_format' => 'string',
            ),
            array(
                'key' => 'field_65d3714ebd6d5',
                'label' => 'Colore testo',
                'name' => 'colore_testo',
                'aria-label' => '',
                'type' => 'color_picker',
                'instructions' => '',
                'required' => 0,
                'conditional_logic' => 0,
                'wrapper' => array(
                    'width' => '50',
                    'class' => '',
                    'id' => '',
                ),
                'default_value' => '',
                'enable_opacity' => 0,
                'return_format' => 'string',
            ),
            array(
                'key' => 'field_65d3810a795e6',
                'label' => 'Colore di testo:hover',
                'name' => 'colore_di_testo_hover',
                'aria-label' => '',
                'type' => 'color_picker',
                'instructions' => '',
                'required' => 0,
                'conditional_logic' => 0,
                'wrapper' => array(
                    'width' => '50',
                    'class' => '',
                    'id' => '',
                ),
                'default_value' => '',
                'enable_opacity' => 0,
                'return_format' => 'string',
            ),
            array(
                'key' => 'field_65d3715bbd6d6',
                'label' => 'Raggio del bordo',
                'name' => 'raggio_del_bordo',
                'aria-label' => '',
                'type' => 'number',
                'instructions' => '',
                'required' => 0,
                'conditional_logic' => 0,
                'wrapper' => array(
                    'width' => '11',
                    'class' => '',
                    'id' => '',
                ),
                'default_value' => '',
                'min' => '',
                'max' => '',
                'placeholder' => '0px',
                'step' => '',
                'prepend' => '',
                'append' => 'px',
            ),
            array(
                'key' => 'field_65d38128795e7',
                'label' => 'Colore bordo',
                'name' => 'colore_bordo',
                'aria-label' => '',
                'type' => 'color_picker',
                'instructions' => '',
                'required' => 0,
                'conditional_logic' => 0,
                'wrapper' => array(
                    'width' => '33',
                    'class' => '',
                    'id' => '',
                ),
                'default_value' => '',
                'enable_opacity' => 1,
                'return_format' => 'string',
            ),
            array(
                'key' => 'field_65d3831b22d11',
                'label' => 'Spessore bordo',
                'name' => 'spessore_bordo',
                'aria-label' => '',
                'type' => 'number',
                'instructions' => '',
                'required' => 0,
                'conditional_logic' => 0,
                'wrapper' => array(
                    'width' => '33',
                    'class' => '',
                    'id' => '',
                ),
                'default_value' => '',
                'min' => '',
                'max' => '',
                'placeholder' => '',
                'step' => '',
                'prepend' => '',
                'append' => 'px',
            ),
            array(
                'key' => 'field_65d383cedbb11',
                'label' => 'Colore bordo:hover',
                'name' => 'colore_bordo_hover',
                'aria-label' => '',
                'type' => 'color_picker',
                'instructions' => '',
                'required' => 0,
                'conditional_logic' => 0,
                'wrapper' => array(
                    'width' => '23',
                    'class' => '',
                    'id' => '',
                ),
                'default_value' => '',
                'enable_opacity' => 0,
                'return_format' => 'string',
            ),
        ),
        'location' => array(
            array(
                array(
                    'param' => 'options_page',
                    'operator' => '==',
                    'value' => 'theme-general-settings',
                ),
            ),
        ),
        'menu_order' => 0,
        'position' => 'normal',
        'style' => 'default',
        'label_placement' => 'top',
        'instruction_placement' => 'label',
        'hide_on_screen' => '',
        'active' => true,
        'description' => '',
        'show_in_rest' => 0,
    ) );
    
        acf_add_local_field_group( array(
        'key' => 'group_65d388b511755',
        'title' => 'Stile globale tipografia',
        'fields' => array(
            array(
                'key' => 'field_65d38cc2a9914',
                'label' => 'H1 font size desktop',
                'name' => 'h1_font_size_desktop',
                'aria-label' => '',
                'type' => 'number',
                'instructions' => '',
                'required' => 0,
                'conditional_logic' => 0,
                'wrapper' => array(
                    'width' => '50',
                    'class' => '',
                    'id' => '',
                ),
                'default_value' => '',
                'min' => '',
                'max' => '',
                'placeholder' => '',
                'step' => '',
                'prepend' => '',
                'append' => 'px',
            ),
            array(
                'key' => 'field_65d38cdda9915',
                'label' => 'H1 font size mobile',
                'name' => 'h1_font_size_mobile',
                'aria-label' => '',
                'type' => 'number',
                'instructions' => '',
                'required' => 0,
                'conditional_logic' => 0,
                'wrapper' => array(
                    'width' => '50',
                    'class' => '',
                    'id' => '',
                ),
                'default_value' => '',
                'min' => '',
                'max' => '',
                'placeholder' => '',
                'step' => '',
                'prepend' => '',
                'append' => 'px',
            ),
            array(
                'key' => 'field_65d38cf932de0',
                'label' => 'H2 font size desktop',
                'name' => 'h2_font_size_desktop',
                'aria-label' => '',
                'type' => 'number',
                'instructions' => '',
                'required' => 0,
                'conditional_logic' => 0,
                'wrapper' => array(
                    'width' => '50',
                    'class' => '',
                    'id' => '',
                ),
                'default_value' => '',
                'min' => '',
                'max' => '',
                'placeholder' => '',
                'step' => '',
                'prepend' => '',
                'append' => 'px',
            ),
            array(
                'key' => 'field_65d38cf932de1',
                'label' => 'H2 font size mobile',
                'name' => 'h2_font_size_mobile',
                'aria-label' => '',
                'type' => 'number',
                'instructions' => '',
                'required' => 0,
                'conditional_logic' => 0,
                'wrapper' => array(
                    'width' => '50',
                    'class' => '',
                    'id' => '',
                ),
                'default_value' => '',
                'min' => '',
                'max' => '',
                'placeholder' => '',
                'step' => '',
                'prepend' => '',
                'append' => 'px',
            ),
            array(
                'key' => 'field_65d38d1832de3',
                'label' => 'H3 font size desktop',
                'name' => 'h3_font_size_desktop',
                'aria-label' => '',
                'type' => 'number',
                'instructions' => '',
                'required' => 0,
                'conditional_logic' => 0,
                'wrapper' => array(
                    'width' => '50',
                    'class' => '',
                    'id' => '',
                ),
                'default_value' => '',
                'min' => '',
                'max' => '',
                'placeholder' => '',
                'step' => '',
                'prepend' => '',
                'append' => 'px',
            ),
            array(
                'key' => 'field_65d38d1832de4',
                'label' => 'H3 font size mobile',
                'name' => 'h3_font_size_mobile',
                'aria-label' => '',
                'type' => 'number',
                'instructions' => '',
                'required' => 0,
                'conditional_logic' => 0,
                'wrapper' => array(
                    'width' => '50',
                    'class' => '',
                    'id' => '',
                ),
                'default_value' => '',
                'min' => '',
                'max' => '',
                'placeholder' => '',
                'step' => '',
                'prepend' => '',
                'append' => 'px',
            ),
        ),
        'location' => array(
            array(
                array(
                    'param' => 'options_page',
                    'operator' => '==',
                    'value' => 'theme-general-settings',
                ),
            ),
        ),
        'menu_order' => 0,
        'position' => 'normal',
        'style' => 'default',
        'label_placement' => 'top',
        'instruction_placement' => 'label',
        'hide_on_screen' => '',
        'active' => true,
        'description' => '',
        'show_in_rest' => 0,
    ) );
    } );
    
    
//ANCHOR Stili globali
    
    add_action('wp_head', 'custom_global_styles');

    function custom_global_styles() {

    // Buttons    
    $background_color = get_field('colore_di_sfondo', 'option');
    $background_color_hover = get_field('colore_di_sfondo_hover', 'option'); 
    $text_color = get_field('colore_testo', 'option'); 
    $text_color_hover = get_field('colore_di_testo_hover', 'option'); 
    $border_radius = get_field('raggio_del_bordo', 'option');
    $border_color = get_field('colore_bordo', 'option');
    $border_width = get_field('spessore_bordo', 'option');
    $border_color_hover = get_field('colore_bordo_hover', 'option');

    // Tipografia
    $h1_font_size_desktop = get_field('h1_font_size_desktop', 'option');
    $h1_font_size_mobile = get_field('h1_font_size_mobile', 'option'); 

    $h2_font_size_desktop = get_field('h2_font_size_desktop', 'option'); 
    $h2_font_size_mobile = get_field('h2_font_size_mobile', 'option'); 

    $h3_font_size_desktop = get_field('h3_font_size_desktop', 'option'); 
    $h3_font_size_mobile = get_field('h3_font_size_mobile', 'option'); 
    

    if($background_color || $text_color || $border_radius) {
        echo '<style>';
        echo '.btn:not(.btn-ghost) {';
        if($background_color) {
            echo 'background-color: ' . $background_color . ';';
        }
        if($text_color) {
            echo 'color: ' . $text_color . ';';
        }
        if($border_radius) {
            echo 'border-radius: ' . $border_radius . 'px;';
        }
        if($border_color) {
            echo 'border-color: ' .  $border_color . ';';
        }
        if($border_width) {
            echo 'border-width: ' .  $border_width . 'px;';
        }
        echo '}';


        echo '.btn:hover {';
            if($background_color_hover) {
                echo 'background-color: ' . $background_color_hover . ';';
            }
            if($text_color_hover) {
                echo 'color: ' . $text_color_hover . ';';
            }
            if($border_color_hover) {
                echo 'border-color: ' . $border_color_hover . ';';
            }
        echo '}';


        // Stili per h1 su desktop
        echo 'h1 {';
        if($h1_font_size_desktop) {
            echo 'font-size:' . $h1_font_size_desktop . 'px !important;';
        }
        echo '}';
        
        // Media query per stili h1 su dispositivi mobili
        echo '@media (max-width: 768px) {';
        echo 'h1 {';
        if($h1_font_size_mobile) {
            echo 'font-size:' . $h1_font_size_mobile . 'px !important;';
        }
        echo '}';
        echo '}'; 

        echo 'h2 {';
                if($h2_font_size_desktop) {
                    echo 'font-size:' . $h2_font_size_desktop . 'px !important;';
                }
            echo '}';

        // Media query per stili h2 su dispositivi mobili
            echo '@media (max-width: 768px) {';
            echo 'h2 {';
            if($h2_font_size_mobile) {
                echo 'font-size:' . $h2_font_size_mobile . 'px !important;';
            }
            echo '}';
            echo '}';    

        echo 'h3 {';
                if($h3_font_size_desktop) {
                    echo 'font-size:' . $h3_font_size_desktop . 'px !important;';
                }
            echo '}';
            
        // Media query per stili h3 su dispositivi mobili
        echo '@media (max-width: 768px) {';
            echo 'h3 {';
            if($h3_font_size_mobile ) {
                echo 'font-size:' . $h3_font_size_mobile  . 'px !important;';
            }
            echo '}';
            echo '}';    

        echo '</style>';
    }
}


?>






