<!DOCTYPE html>



<html lang="en">



<head>



    <meta charset="UTF-8">



    <meta http-equiv="X-UA-Compatible" content="IE=edge">



    <meta name="viewport" content="width=device-width, initial-scale=1.0">







    <?php wp_head(); ?>







    







</head>



<body <?php body_class(); ?> >



    <?php $header_bg_color = get_field('colore_di_sfondo_header','option'); ?>



    <header class="flex-wrap pt-2 md:pt-4 md:pb-2 sticky top-0 bg-[<?php echo esc_attr( $header_bg_color ); ?>] z-10 shadow shadow-gray-300">



      



    <div class="m-auto md:w-[1300px] flex justify-between ">




    <div class="navbar rounded py-3">



        <div class="navbar-start w-[65%] md:w-[50%]">



            <div class="dropdown">



                <label tabindex="0" class="btn btn-ghost lg:hidden">



                    <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h8m-8 6h16" /></svg>



                </label>



                <ul tabindex="0" class="menu menu-sm dropdown-content mt-3 z-[1] p-2 shadow bg-slate-200 rounded-box w-52 z-10">



                <?php



                wp_nav_menu(array(



                    'theme_location' => 'primary',



                        'container' => 'nav'



                    ));



                ?>



                </ul>



                </div>



                <a href="<?php echo home_url(); ?>"><?php the_custom_logo()?></a>



            </div>



                <?php



                wp_nav_menu(array(



                    'theme_location' => 'primary',



                        'container' => 'nav',



                        'container_class' => 'navbar-center hidden lg:flex',



                        'menu_class' => 'menu menu-horizontal px-1 text-[16px] text-slate-600 uppercase font-semibold',



                    ));



                ?>



        <div class="navbar-end w-[36%] md:w-[50%]">



    <a class="btn-primary btn" href="#">Button</a>



  </div>



</div>







    </header>







    <div class="m-auto">



    



